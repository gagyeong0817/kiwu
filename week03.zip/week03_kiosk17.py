# week03_kiosk17
total_price = 0  # 총 금액
drinks = ["Espresso", "Cafe latte", "Hot choco", "Plain smoothie"]  # 음료 리스트
prices = [2200, 3500, 3800, 5000]  # 가격 리스트
# 수량
amounts = [0 for _ in range(len(drinks))]  # list comprehension
# 디스플레이 메뉴
menu_texts = ''.join([f"{j+1}) {drinks[j]} {prices[j]} won " for j in range(len(drinks))])
menu_texts = menu_texts + f" {len(drinks)+1}) Exit : "

def order_process(idx):
    global total_price  # order_process 함수 바깥 쪽에 선언되어 있는 total_price 전역 변수를 참조하기 위해 사용
    print(f"{drinks[idx]} ordered. Price : {prices[idx]} won")
    total_price = total_price + prices[idx]
    amounts[idx] = amounts[idx] + 1


while True:
    menu = input(menu_texts)
    if menu == "1":
        order_process(int(menu) - 1)  # order_process(0)
    elif menu == "2":
        order_process(int(menu) - 1)
    elif menu == "3":
        order_process(int(menu) - 1)
    elif menu == "4":
        order_process(int(menu) - 1)
    elif menu == "5":
        print("Finish order!")
        break

print(f"Product  Price  Amount  Subtotal")
for i in range(len(drinks)):
    if amounts[i] != 0:
        print(f"{drinks[i]} {prices[i]} x{amounts[i]} {prices[i] * amounts[i]} won")
print(f"Total price : {total_price} won")
